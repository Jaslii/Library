public class Book extends Content { //partners: Malaya Jove, Matthew Ryan, David Mason
    private String author;
    private int PageCount;
    private String callNumber;

    private int ISBN;
    private String authorFN;
    private String authorLN;
    private int year;

    public Book(String title, String authorFN, String authorLN, int year) {
        super(title);
        this.authorFN =  authorFN;
        this.authorLN =  authorLN;
        this.callNumber = authorLN + authorFN.charAt(0) + year;
        setYear(year);

    }
    public void setPageCount(int pageCount) {
        this.PageCount =  pageCount;
    }
    public int getPageCount(){
        return PageCount;
    }
    public String getCallNumber() {
        return callNumber;
    }
    public String getAuthor() {
        return author;
    }
    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }
    public void setYear(int year) {
        this.year = year;
    }

}
// -Jungsol Lee