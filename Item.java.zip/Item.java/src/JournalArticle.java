public class JournalArticle extends Content{ //partners: Malaya Jove, Matthew Ryan, David Mason
    private String author;
    private String journal;
    private int year;
    private int volume;
    private int issue;
    private int SPage;
    private int EPage;

    public JournalArticle(String title, String author, String journal, int year, int volume, int SPage, int EPage) {
        super(title);
        this.author = author;
        this.journal = journal;
        this.year = year;
        this.volume = volume;
        this.issue = issue;
        this.SPage = SPage;
        this.EPage = EPage;
    }
    public String getAuthor() {
        return author;
    }
    public String getJournal() {
        return journal;
    }
    public int getYear() {
        return year;
    }
    public int getVolume() {
        return volume;
    }
    public int getIssue() {
        return issue;
    }
    public int getSPage() {
        return SPage;
    }
    public int getEPage() {
        return EPage;
    }

}
// -Jungsol Lee
