public class Magazine extends Book { //partners: Malaya Jove, Matthew Ryan, David Mason
    private String title;
    private String author;
    private String authorLN;
    private int year;

    public Magazine(String title, String author, String authorLN,  int year) {
        super(title, author,authorLN, year);
        this.title = title;
        this.author = author;
        this.authorLN = authorLN;
        this.year = year;

    }
    public String getCallNumber() {
        return "MAGAZINE";
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getAuthorLN() {
        return authorLN;
    }
    public int getYear() {
        return year;
    }
}
// -Jungsol Lee